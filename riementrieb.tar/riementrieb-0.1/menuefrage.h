#ifndef MENUEFRAGE_INC_
#define MENUEFRAGE_INC_

#include <iostream>
#include <string>

int MenueFrage(void);

#endif